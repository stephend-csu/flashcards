#!/home/cuisinart/.virtualenvs/Sprache/bin/python
import csv, os, time, random, curses
from os import walk
import termios, sys , tty

def _getch():
   fd = sys.stdin.fileno()
   old_settings = termios.tcgetattr(fd)
   try:
      tty.setraw(fd)
      ch = sys.stdin.read(1)     #This number represents the length
   finally:
      termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
   return ch

list_of_files = {}
for (dirpath, dirnames, filenames) in os.walk(os.getcwd()):
    for filename in filenames:
        if filename.endswith('.csv'): 
            list_of_files[filename] = os.sep.join([dirpath, filename])

list_of_files=dict(sorted(list_of_files.items()))

while(1):
    m=0
    for x in list_of_files:
        m+=1
        if((m+2)%3==0):
            print()
        print("{:2d} {:<22}".format(m,x[:-4]),end=' ')
    print("\n\n{:2d} {:<22}  q Quit".format(0,"Random deck [?]"),end=' ')

    filenames=[]
    for key, value in list_of_files.items():
        filenames.append(value)

    print('\n\n # [Enter]: ',end='')
    user_input=''

    file_numbers=range(len(filenames)+1)[1:]

    while user_input not in file_numbers:
        user_input=input()
        if (user_input=='q'):
            print('\n\n')
            exit()
        user_input=int(user_input)
        if (user_input==0):
            user_input=random.choice(file_numbers)
            break

    x=user_input-1

    os.system('clear')

    fields = []
    rows = []

    with open(filenames[x],'r') as csvfile:
        csvreader = csv.reader(csvfile)

        for row in csvreader:
            rows.append(row)

        #print("Total no. of rows: %d"%(csvreader.line_num))

    random.shuffle(rows)
    for i in range(len(rows)):
        counter=len(rows)-i
        print('\n')
        print("\t{}\t{}\n\n".format(counter,rows[i][0]))
        user_input=_getch()
        if(user_input=='q'):
            print('\n\n')
            exit()
        os.system('clear')
        print('\n')
        print("\t{}\t{}\n\n".format(counter,rows[i][1]))
        user_input=_getch()
        if(user_input=='q'):
            print('\n\n')
            exit()
        os.system('clear')
